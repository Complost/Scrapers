# -*- coding: utf-8 -*-    

import hosters       

def get_hosters():    
    return hosters.__all__    
